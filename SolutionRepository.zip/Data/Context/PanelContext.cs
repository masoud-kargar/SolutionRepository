﻿using Domain;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

using System.Reflection;

namespace Data {
    public class PanelContext :IdentityDbContext {
        public PanelContext(DbContextOptions<PanelContext> options) : base(options) { }
        public DbSet<Person> People { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<BlogNew> BlogNews { get; set; }
        public DbSet<PageComment> PageComments { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            //Seed Data
            modelBuilder.Entity<Person>().HasData(new Person { Name = "Masoud", Family = "Kargar" });
        }
    }
}
