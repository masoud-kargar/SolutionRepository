﻿
namespace Domain {
    public class Person : BaseEntity {
        public string Name { get; set; }
        public string Family { get; set; }
    }
}
