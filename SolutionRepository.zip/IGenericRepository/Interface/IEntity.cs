﻿using System;

namespace AllInterfaces {
    public interface IEntity {
        public Guid Id { get; set; }
    }
}
