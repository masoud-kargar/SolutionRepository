﻿using System;

namespace IGenericRepository {
    public interface IEntity {
        public Guid Id { get; set; }
    }
}
